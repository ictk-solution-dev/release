import sys
import auth_lib
from setuptools import setup, find_packages, Extension
from setuptools.command.install import install

from auth_lib.ictk_ssl_ext import get_c_build_extention

currentVersion = auth_lib.__version__

#from distutils.core import setup
from setuptools import setup


import subprocess

class InstallLocalPackage(install):
	def run(self):
		install.run(self)
		subprocess.call(
			"python path_to/local_pkg/build_hello.py install", shell=True
		)


module_ext = get_c_build_extention.main('auth_lib/ictk_ssl_ext/ictk_ssl_ext_c', 'auth_lib.ictk_ssl_ext._ictk_ssl_ext')


print(find_packages())
setup(
	name = 'auth_comm_lib',
	packages=['auth_lib','auth_lib.ictk_ssl_ext'],
	# package_dir={'mypkg': 'src/mypkg'},  # didnt use this.
	package_data={
		# If any package contains *.txt or *.rst files, include them:
		'': ['*.h', '*.css', '*.html','*.json','*.xlsx','*.sql','*.pyd'],
	},

	version = currentVersion,
	description = 'this module 4 ictk company mannfacturre',
	author = 'neo1seok',
	author_email = 'neo1seok.ictk@gmail.com',
	keywords = ['auth_comm_lib', 'neo1seok'],
	dependency_links=['https://github.com/neo1seok/neolib_python.git@master'],
	install_requires=[
		"neolib",


	],
	classifiers = [
		"Development Status :: 5 - Production/Stable",
		"Intended Audience :: Developers",
		"Natural Language :: English",
		"License :: neo1seok licnese",
		"Programming Language :: Python",
		"Programming Language :: Python :: 3",
		"Programming Language :: Python :: 3.3",
		"Programming Language :: Python :: 3.4",
		"Programming Language :: Python :: 3.5",
		"Programming Language :: Python :: 3.6"
	],
	ext_modules = [module_ext]


)
