#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/bn.h>
#include <openssl/ecdsa.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/asn1.h>
#include <openssl/asn1t.h>
#include <openssl/ossl_typ.h>
#include <openssl/conf.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <memory.h>
#include <string.h>
#include"util.h"
#include <stdlib.h>

FILE * _fpout = stdout;

void set_fp(FILE * fp){
	_fpout = fp;
}
FILE * get_fp()
{
	return _fpout;
}
//======================================================================
//
//======================================================================
int rand_serial(BIGNUM *b, ASN1_INTEGER *ai)
{
	BIGNUM *btmp = NULL;
	int ret = 0;



	if (b)
		btmp = b;
	else
		btmp = BN_new();

	if (!btmp)
		return 0;

	if (!BN_pseudo_rand(btmp, 64/*SERIAL_RAND_BITS*/, 0, 0))
		goto error;
	if (ai && !BN_to_ASN1_INTEGER(btmp, ai))
		goto error;

	ret = 1;

error:

	if (btmp)
		BN_free(btmp);

	return ret;
}


void print_hex(const  char* msg, int len, const unsigned char* buf)
{
	fprintf(_fpout,"%s [", msg);
	for (int i = 0; i < len; i++)
	{
		fprintf(_fpout,"%02X", buf[i]);
	}

	fprintf(_fpout,"]\n");

}

BIO* get_bio_from_file(const char * filename)
{

	char szbuff[4096] = { 0, };

	//BIO *BIO_new_mem_buf(const void *buf, int len);
	FILE * fp = fopen(filename, "rb");
	if (!fp) return NULL;

	int size = fread(szbuff, 1, 4096, fp);

	BIO* cabio = NULL;
	cabio = BIO_new_mem_buf(szbuff, size);
	fclose(fp);
	return cabio;
}

int get_buffinfo_from_file(const char * filename, BUFFINFO *buffinfo) 
{

	char szbuff[4096] = { 0, };

	//BIO *BIO_new_mem_buf(const void *buf, int len);
	FILE * fp = fopen(filename, "rb");
	if (!fp) return -1;

	int size = fread(szbuff, 1, 4096, fp);
	buffinfo->size = size;
	memcpy(buffinfo->buff, szbuff, size);
	
	fclose(fp);
	return 0;

}
int neo_bin_bub_to_ec_key(const unsigned char* aucPubKey, EC_KEY** eckey)
{
	BIGNUM* x = NULL;
	BIGNUM* y = NULL;

	EC_GROUP *group = NULL;
	EC_POINT *ecp = NULL;
	int ret = 0;
	group = EC_GROUP_new_by_curve_name(NID_X9_62_prime256v1);
	if (group == NULL)
	{
		fprintf(_fpout,"EC_GROUP_new_by_curve_name()\n");
		ret = 0xFFFFFFA4;
		goto end_pos;
	}
	

	EC_GROUP_set_asn1_flag(group, OPENSSL_EC_NAMED_CURVE);
	EC_GROUP_set_point_conversion_form(group, POINT_CONVERSION_UNCOMPRESSED);

	ecp = EC_POINT_new(group);
	if (ecp == NULL)
	{
		fprintf(_fpout,"EC_POINT_new()\n");

		ret = 0xFFFFFFA4;
		goto end_pos;
	}

	*eckey = EC_KEY_new();
	if (*eckey == NULL)
	{
		fprintf(_fpout,"EC_KEY_new()\n");

		ret = 0xFFFFFFA4;
		goto end_pos;
	}
	EC_KEY_set_group(*eckey, group);

	x = BN_new();
	y = BN_new();

	if (!BN_bin2bn(aucPubKey, 32, x))
	{
		fprintf(_fpout,"BN_bin2bn():X\n");

		ret = 0xFFFFFFA4;
		goto end_pos;
	}

	if (!BN_bin2bn(&aucPubKey[32], 32, y))
	{
		fprintf(_fpout,"BN_bin2bn():Y\n");

		ret = 0xFFFFFFA5;
		goto end_pos;
	}

	if (!EC_POINT_set_affine_coordinates_GFp(group, ecp, x, y, NULL))
	{
		fprintf(_fpout,"EC_POINT_set_affine_coordinates_GFp()\n");

		ret = 0xFFFFFFA6;
		goto end_pos;
	}

	if (!EC_KEY_set_public_key(*eckey, ecp))
	{
		fprintf(_fpout,"EC_KEY_set_public_key()\n");
		ret = 0xFFFFFFA7;
		goto end_pos;
	}
end_pos :
	if (ecp) EC_POINT_free(ecp);
	if (x) BN_clear_free(x);
	if (y) BN_clear_free(y);
	if(group) EC_GROUP_free(group);

	return ret;

}
unsigned short messageDigest(const unsigned char *pucData, unsigned short usDataLen, unsigned char* pucHash)
{
	SHA256_CTX sha256;
	SHA256_Init(&sha256);
	SHA256_Update(&sha256, pucData, usDataLen);
	SHA256_Final(pucHash, &sha256);

	return 0x0000;

}

int Bn2Bin(const BIGNUM * pbignum, unsigned char *pbuff, int bytesize)
{
	int oldbytsize = BN_num_bytes(pbignum);

	if (oldbytsize > bytesize) return 0;
	memset(pbuff, 0x00, bytesize);

	int startpos = bytesize - oldbytsize;
	int sizee = BN_bn2bin(pbignum, pbuff + startpos);
	return bytesize;
}

#if 0
int convert_64sign_to_asn1(const unsigned char *sign64value,int sign64valueSize,unsigned char * asn1, int * asn1size) 
{
	
	BIGNUM * orgbnr = NULL;
	BIGNUM * orgbns = NULL;
	ECDSA_SIG *sign = NULL;

	if (sign64valueSize != 64) return -1;

	sign = ECDSA_SIG_new();



	orgbnr = sign->r;
	orgbns = sign->s;

	sign->r = BN_bin2bn(sign64value,32,NULL);
	sign->s = BN_bin2bn(sign64value+32, 32, NULL);

	unsigned char *buff = NULL;
	int signleng = i2d_ECDSA_SIG(sign, &buff);

	memcpy(asn1, buff, signleng);
	*asn1size = signleng;
	
	if(sign->r) BN_free(sign->r);
	if (sign->s) BN_free(sign->s);


	if (sign) {

		sign->r = orgbnr;
		sign->s = orgbns;

		ECDSA_SIG_free(sign);
	}

	if (buff) {
		//OPENSSL_cleanse((char *)buff, (unsigned int)signleng);
		OPENSSL_free(buff);
	}


	return 0;
}




int convert_64sign_to_asn1_test(const unsigned char *sign64value, int sign64valueSize, unsigned char * asn1, int * asn1size)
{
	ECDSA_SIG *sign = NULL;
	unsigned char *buff = NULL;
    int signleng =0;
	if (sign64valueSize != 64) return -1;
	
	sign = ECDSA_SIG_new();

	

	sign->r = BN_bin2bn(sign64value, 32, NULL);
	sign->s = BN_bin2bn(sign64value + 32, 32, NULL);

	goto end;
	
	signleng = i2d_ECDSA_SIG(sign, &buff);

	memcpy(asn1, buff, signleng);
	*asn1size = signleng;
end:
	
	if (sign){
		
		if (sign->r) {
			//printf("free r");
			BN_clear_free(sign->r);
		}
		if (sign->s) {
			//printf("free s");
			BN_clear_free(sign->s);
		}

		sign->r = NULL;
		sign->s = NULL;


		ECDSA_SIG_free(sign);
	}

	if (buff) {
		//OPENSSL_cleanse((char *)buff, (unsigned int)signleng);
		OPENSSL_free(buff);
	}


	return 0;
}

int temp_test(const unsigned char *sign64value, int sign64valueSize)
{
	ECDSA_SIG *sign = NULL;
	unsigned char *buff = NULL;
	BIGNUM * bnr = NULL;
	BIGNUM * bns = NULL;
	BIGNUM * orgbnr = NULL;
	BIGNUM * orgbns = NULL;


	

	sign = ECDSA_SIG_new();
	/*sign->r = 
	sign->s = */

	
	
	
	orgbnr = sign->r;
	orgbns = sign->s;

	sign->r = BN_bin2bn(sign64value, 32, NULL);
	sign->s = BN_bin2bn(sign64value + 32, 32, NULL);

	





	if (sign->r) {
		//printf("free r");
		BN_clear_free(sign->r);
	}
	if (sign->s) {
		//printf("free r");
		BN_clear_free(sign->s);
	}
	if (sign){
		sign->r = orgbnr;
		sign->s = orgbns;
		ECDSA_SIG_free(sign);
	}


	return 0;
}
int convert_asn1_to_64sign( const unsigned char * asn1, int asn1size, unsigned char *sign64value, int * sign64valueSize )
{
	

	ECDSA_SIG *sign = d2i_ECDSA_SIG(NULL,  &asn1, asn1size);
	if (!sign) return -1;
	int size = 0;
	size += Bn2Bin(sign->r, sign64value,32);
	size += Bn2Bin(sign->s, sign64value+32, 32);
	*sign64valueSize = 64;
	if (sign) ECDSA_SIG_free(sign);
	

	return 0;
}

int ecdsa(const unsigned char *prk, int prk_size, const unsigned char *msg, int msg_size, unsigned char *sign,int *psign_size,bool is_hashed){
	//printf("test ecdsa");
	EC_GROUP *g_ecc_group = NULL;
	BN_CTX *ctx = NULL;
	EC_KEY *g_ecc_key = NULL;
	BIGNUM *bn_private_key = NULL;
	ECDSA_SIG * psign = NULL;
	char * hexstr_r = NULL;
	char * hexstr_s = NULL;
	unsigned char hashed_msg[32];
	int ret = 0;
	int size = 0;
	
	g_ecc_group = EC_GROUP_new_by_curve_name(NID_X9_62_prime256v1);
	ctx = BN_CTX_new();
	g_ecc_key = EC_KEY_new();// # Ű�Ҵ�
	if (!EC_KEY_set_group(g_ecc_key, g_ecc_group)){

		ret = -1;
		goto end;
	}
	

	
	
	//bn_private_key = BN_new();
	bn_private_key = BN_bin2bn(prk, prk_size, NULL);
	if (!EC_KEY_set_private_key(g_ecc_key, bn_private_key)){
		ret = -1;
		goto end;
	}


	if (is_hashed)
		memcpy(hashed_msg, msg, 32);
	else
		messageDigest(msg, msg_size, hashed_msg);

	psign = ECDSA_do_sign(hashed_msg, 32, g_ecc_key);
	size += Bn2Bin(psign->r, sign, *psign_size/2);
	size += Bn2Bin(psign->s, sign + 32, *psign_size / 2);

	*psign_size = size;
end:
	if (psign)
		ECDSA_SIG_free(psign);

	if (ctx)
		BN_CTX_free(ctx);

	if (g_ecc_key)
		EC_KEY_free(g_ecc_key);

	if(g_ecc_group)
		EC_GROUP_free(g_ecc_group);
	
	if (bn_private_key)
		BN_free(bn_private_key);

	return ret;





}

void inverse_bytes(void * bytes, int bytes_size) {
	unsigned char* tempbytes = (unsigned char*)malloc(bytes_size);
	unsigned char* pbytes = (unsigned char*)bytes;
	unsigned char* pdstreverse = tempbytes+ bytes_size-1;
	memcpy(tempbytes, bytes, bytes_size);

	for (int i = 0; i < bytes_size; i++, pbytes++, pdstreverse--) {
		*pbytes = *pdstreverse;
	}

	free(tempbytes);




}
int conv_longlong_to_asn1_integer(ASN1_INTEGER *ai,long long num  )
{
	BIGNUM *btmp = NULL;
	int ret = 0;
	
	inverse_bytes(&num,8);
	
	print_hex("############num", 8,(const unsigned char*) &num);
	
	btmp = BN_new();

	if (!btmp)
		return 0;
	
	
	if (!BN_bin2bn((const unsigned char*)&num, 8, btmp)) 
		goto error;

	if (ai && !BN_to_ASN1_INTEGER(btmp, ai))
		goto error;

	ret = 1;

error:

	if (btmp)
		BN_free(btmp);

	return ret;
}

#endif