
from setuptools import setup, find_packages, Extension
from setuptools.command.install import install

import get_c_build_extention
#
# base_cert_signer_dir = 'cert_signer_c'
# list_src = ['py_main.cpp','py_test.cpp','util.cpp','neo_cert.cpp']
# sources = [ base_cert_signer_dir +"/"+tmp for tmp in list_src]
#
# module1 = Extension('_cert_signer',
#                 include_dirs = ['cert_signer_c/inc'],
#                     libraries = ['libeay32'],
#                     library_dirs = ['cert_signer_c/lib'],
#                     sources = sources
#                     )
module1 = get_c_build_extention.main('ictk_ssl_ext_c','_ictk_ssl_ext')
setup (name = 'PackageName',
       version = '1.0',
       description = 'This is a demo package',
       ext_modules = [module1])