#pragma once
#ifndef __NEO_CERT_HEADER__
#define __NEO_CERT_HEADER__

#define MAX_SUBJECT_INFO_NUM 10
typedef int(*PF_ECDSA_SIGN)(unsigned char* indata, int indataLen, unsigned char* pucSigBuf, int* pusSigLen, int is_hashed, void * param);



typedef struct _tagSUBJECTINFO {

	int nid;
	int type;
	//char value[512];
	char value[512];

}SUBJECTINFO, *LPSUBJECTINFO;

typedef struct _tagSUBJECTSUBJECTARRAY {

	int size;
	SUBJECTINFO subject_info[MAX_SUBJECT_INFO_NUM];
}SUBJECTARRAY;




void load_default();

void load_files(const char * szCAFile, const char*szExtConfFile);
void load_buffer(const unsigned char * ca_buff, int ca_buff_size, const unsigned char * ext_conf_buff, int ext_conf_buff_size);
//�������� ������Ʈ ������ �Է� �Ѵ�. 
//ca �������� ������ extern conf���� �Է� �Ѵ�.


void clear_subject();
int add_subject_info(int nid, int type, const char * value);
//�������� ������Ʈ ������ �Է� �Ѵ�. 

int neo_generate_cert(
	const unsigned char* szSn,
	const unsigned char* aucPubKey,
	PF_ECDSA_SIGN pf_ecdsa_sign, 
	void *csr_param,
	void *ctr_param,
	unsigned char*	puccertsDer,
	unsigned int*	puiCertsDerLen


);


int neo_make_x509_tbs(
	const unsigned char* szSn,
	const unsigned char* aucPubKey,
	unsigned char*	tbs,
	int*	tbsSize


);
int neo_make_x509_tbs_ex(
	
	const unsigned char* szSn,
	const unsigned char* aucPubKey,
	unsigned char*	tbs,
	int*	tbsSize,
	long long cert_serial_number




);

int neo_make_x509_from_tbs_n_sign(
	const unsigned char* tbs,
	unsigned int	tbsSize,
	const unsigned char* signasn1,
	int	signasn1Size,
	unsigned char*	certsDer,
	int*	certsDerLen


);
int neo_parse_x509_to_tbs_n_sign(
	const unsigned char*	certsDer,
	int	certsDerLen,
	unsigned char* tbs,
	int	* tbsSize,
	unsigned char* signasn1,
	int	*signasn1Size

);
//szSn�� add_subject_info�� ���ؼ� �Է� �Ҽ� �ִ�.
int neo_verify_cert_by_ca(const unsigned char*	puccertsDer,
	int		uiCertsDerLen);
int neo_get_pubkey_from_cert(const  unsigned char*	puccertsDer,
	int		uiCertsDerLen,
	unsigned char*	pubkey64,
	int* 		pubkey64_size);

#endif // !__NEO_CERT_HEADER__
