from setuptools import  Extension
import sys


def main(base_cert_signer_dir,module_name):
	#base_cert_signer_dir = 'product_machine/cert_tool/cert_signer_c'
	extra_compile_args = [
		                     '-fpermissive',

	                     ]

	if sys.platform == 'win32':
		libraries = ['libcrypto','libssl','User32','ws2_32','Advapi32','Crypt32','legacy_stdio_definitions']

	else:
		libraries = ['crypto', 'ssl']
	#User32.lib
	list_src = ['py_main.cpp', 'py_test.cpp', 'util.cpp']

	sources = [base_cert_signer_dir + "/" + tmp for tmp in list_src]

	return Extension(module_name,
	                               include_dirs=[base_cert_signer_dir + '/inc'],
	                               libraries=libraries,
	                               library_dirs=[base_cert_signer_dir + '/lib64'],
	                               sources=sources,extra_compile_args=extra_compile_args)


if __name__ == '__main__':
	main()
	pass
