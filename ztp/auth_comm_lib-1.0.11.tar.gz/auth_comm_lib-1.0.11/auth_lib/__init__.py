# -*- coding: utf-8 -*- 	
__version__ = "1.0.11"
"""
#[ver].[majer].[miner]
#ver: 전체 프레임의 격변이 있을때
#majer:큰 기능 추가가 되었을때
#miner:버그 수정및 작은 기능 추가.
"""
__history__ = """
* 1.0.11
X509Handler update 
 	
* 1.0.10
ictk_ssl_ext 오류 수정 
 	
* 1.0.9
ictk_ssl_ext 오류 수정 
 	
* 1.0.8
ictk_ssl_ext 파일 추가.
 	
* 1.0.7
ictk_ssl_ext 부분을 ztp_broker_switch 로부터 가져옴
 	
* 1.0.6
setup 시 auth_lib 만 추가.
 	
* 1.0.5
setup 시 auth_lib 만 추가.
 	
* 1.0.4
request_api auth_cert 추가.
 	
* 1.0.3
request_api auth_cert 추가.
 	
* 1.0.2
request_api auth_cert 추가.
 	
* 1.0.1
request_api 추가.
 	
* 1.0.0
work info 에서 lock 상태 표시
시작시 Lock이 'TRUE'설정이 안되어 있으면 에러 발생 
배치 입력시 is_lock 안되는 현상 해결

 	
* 1.0.0
first commit
 	"""
	