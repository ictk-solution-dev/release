import cryptography
from cryptography.hazmat.backends.openssl import ec

from auth_lib.request_api import RequestApi
from auth_lib.x509_function import make_verify_cert_pem, make_cert_pem
from auth_lib.x509_handler import X509Handler
from example import sample_cert

import cryptography
from cryptography.hazmat.primitives import serialization
from neolib import neoutil


from example import sample_cert
from cryptography import x509
from cryptography.hazmat._oid import ObjectIdentifier
from cryptography.hazmat.primitives.serialization import Encoding
from cryptography.hazmat.primitives.asymmetric import ec

class ToolUtil():
	def __init__(self,host="127.0.0.1",port=8000,access_token="",ca_cert="", ca_cert_key="", cert="", cert_key=""):
		self.base_url = f"http://{host}:{port}"
		self.rest_api = RequestApi(self.base_url, access_token)
		self.ca_cert = ca_cert
		self.ca_cert_key = ca_cert_key
		self.cert = cert
		self.cert_key = cert_key



	def load_files(self,ca_cert_file="",ca_cert_key_file="",cert_file="",cert_key_file=""):
		if ca_cert_file:
			self.ca_cert = neoutil.StrFromFile(ca_cert_file)

		if ca_cert_key_file:
			self.ca_cert_key = neoutil.StrFromFile(ca_cert_key_file)

		if cert_key_file:
			self.cert_key = neoutil.StrFromFile(cert_key_file)

		if cert_file:
			self.cert = neoutil.StrFromFile(cert_file)

		return self

	def set_cert(self, ca_cert="", ca_cert_key="", cert="", cert_key=""):
		self.ca_cert = ca_cert
		self.ca_cert_key = ca_cert_key
		self.cert = cert
		self.cert_key = cert_key
		return self

	def reg_ca(self,verify_cert_out_file=""):

		res =self.rest_api.post_api("get_reg_code")
		reg_code = res["reg_code"]

		# ca_cert = neoutil.StrFromFile(ca_cert_file)
		# ca_cert_key = neoutil.StrFromFile(ca_cert_key_file)

		ca_verify_cert = make_verify_cert_pem(self.ca_cert,
		                                      reg_code,
		                                      self.ca_cert_key)

		print("ca_verify_cert",ca_verify_cert)
		if verify_cert_out_file:
			with open(verify_cert_out_file, "w") as fo:
				fo.write(ca_verify_cert)


		ret = self.rest_api.reg_ca_and_activate(self.ca_cert,ca_verify_cert,True)
		print(ret)

	def reg_device_cert(self,cert):
		# crypto_be = cryptography.hazmat.backends.default_backend()
		# priv_key = ec.generate_private_key(ec.SECP256R1(), crypto_be)
		#
		# pem_key = priv_key.private_bytes(
		# 	encoding=serialization.Encoding.PEM,
		# 	format=serialization.PrivateFormat.PKCS8,
		# 	encryption_algorithm=serialization.NoEncryption())
		#
		#
		# out_cert = make_cert_pem(self.ca_cert, sample_cert.ca_cert_key, pem_key.decode(),
		#                          common_name)
		# inst = X509Handler(out_cert, encoding="PEM")
		# # exam_reg_device_cert()
		# keyname = inst.to_hash().hexstr
		#
		# if out_cert_file_name_format:
		# 	with open(out_cert_file_name_format.format(name=keyname,ext="crt"), "w") as fo:
		# 		fo.write(out_cert)
		# 	with open(out_cert_file_name_format.format(name=keyname,ext="crt"), "w") as fo:
		# 		fo.write(pem_key.decode())

		post_data = {
			"cert": cert,
			"cert_chain": [self.ca_cert]
		}

		res = self.rest_api.auth_cert(**post_data)
		#res = inst.post_api("auth_cert", **post_data)
		print(res)
		res = self.rest_api.auth_cert(**post_data)
		#res = inst.post_api("auth_cert", **post_data)
		print(res)

	def generate_device_cert(self,common_name = 'ICTK HOLDINGS CLIENT ',out_cert_file_name_format="out/out_{name}.{ext}"):
		crypto_be = cryptography.hazmat.backends.default_backend()
		priv_key = ec.generate_private_key(ec.SECP256R1(), crypto_be)

		pem_key = priv_key.private_bytes(
			encoding=serialization.Encoding.PEM,
			format=serialization.PrivateFormat.PKCS8,
			encryption_algorithm=serialization.NoEncryption())


		out_cert = make_cert_pem(self.ca_cert, self.ca_cert_key, pem_key.decode(),
		                         common_name)
		inst = X509Handler(out_cert, encoding="PEM")
		# exam_reg_device_cert()
		keyname = inst.to_hash().hexstr

		if out_cert_file_name_format:
			with open(out_cert_file_name_format.format(name=keyname,ext="crt"), "w") as fo:
				fo.write(out_cert)
			with open(out_cert_file_name_format.format(name=keyname,ext="crt"), "w") as fo:
				fo.write(pem_key.decode())
		return out_cert,pem_key

		post_data = {
			"cert": out_cert,
			"cert_chain": [self.ca_cert]
		}

		res = self.rest_api.auth_cert(**post_data)
		#res = inst.post_api("auth_cert", **post_data)
		print(res)
		res = self.rest_api.auth_cert(**post_data)
		#res = inst.post_api("auth_cert", **post_data)
		print(res)
