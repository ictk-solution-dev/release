
class AuthLibVerifyCertException(Exception):
	pass

