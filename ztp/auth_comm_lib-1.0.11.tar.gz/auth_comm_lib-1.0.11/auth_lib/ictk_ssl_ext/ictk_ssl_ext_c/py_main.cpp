#include <stdio.h>
#ifndef __NO_PYTHON_BUILD__
#include <Python.h>
#include <errno.h>
#include"neo_cert.h"
#include"util.h"

#include "openssl/rsa.h"
#include "openssl/crypto.h"
#include "openssl/x509.h"
#include "openssl/x509v3.h"
#include "openssl/pem.h"
#include "openssl/ssl.h"
#include "openssl/err.h"
#include "openssl/rand.h"
#include "openssl/bio.h"
#include "openssl/dh.h"


// Module method definitions


/*

unsigned short neo_generate_cert(
	unsigned char* szSn,
	unsigned char* aucPubKey,
	PF_ECDSA_SIGN pf_ecdsa_sign_for_csr,
	PF_ECDSA_SIGN pf_ecdsa_sign_for_cert,
	unsigned char*	puccertsDer,
	unsigned int*	puiCertsDerLen
);


*/

typedef struct {
	PyObject_HEAD
		SSL_CTX *ctx;
#if HAVE_NPN
	unsigned char *npn_protocols;
	int npn_protocols_len;
#endif
#if HAVE_ALPN
	unsigned char *alpn_protocols;
	unsigned int alpn_protocols_len;
#endif
#ifndef OPENSSL_NO_TLSEXT
	PyObject *set_sni_cb;
#endif
	int check_hostname;
	/* OpenSSL has no API to get hostflags from X509_VERIFY_PARAM* struct.
	 * We have to maintain our own copy. OpenSSL's hostflags default to 0.
	 */
	unsigned int hostflags;
	int protocol;
#ifdef TLS1_3_VERSION
	int post_handshake_auth;
#endif
} PySSLContext;

typedef struct {
	int ssl; /* last seen error from SSL */
	int c; /* last seen error from libc */
#ifdef MS_WINDOWS
	int ws; /* last seen error from winsock */
#endif
} _PySSLError;

typedef struct {
	PyObject_HEAD
		PyObject *Socket; /* weakref to socket on which we're layered */
	SSL *ssl;
	PySSLContext *ctx; /* weakref to SSL context */
	char shutdown_seen_zero;
	//enum py_ssl_server_or_client socket_type;
	int socket_type;
	PyObject *owner; /* Python level "owner" passed to servername callback */
	PyObject *server_hostname;
	_PySSLError err; /* last seen error from various sources */
} PySSLSocket;

 PyObject* hello(PyObject *self, PyObject *args);
 PyObject * spam_system(PyObject *self, PyObject *args);
 PyObject *my_set_callback(PyObject *dummy, PyObject *args);
 PyObject *do_callback(PyObject *dummy, PyObject *args);
 

 static PyObject *g_cb_veify = NULL;

 int app_verify_callback(X509_STORE_CTX *ctx, void *args) 

 //static int client_certificate_verify(int preverify_ok, X509_STORE_CTX *ctx)
 {
	 /* Time to call the callback */
	 PyObject *arglist = NULL;
	 PyObject *result = NULL;
	 int ret = 1;
	 int size = 0;
	 char * bytes = NULL;
	 PyObject *vefify_cb = (PyObject *)args;
	 //printf("app_verify_callback 0\n");
	 
	 //PyObject *pyin  = PyBytes_FromStringAndSize((const char*)indata, indataLen);



	 //arglist = Py_BuildValue("i", 1);

	 //printf("app_verify_callback 1\n");

	 result = PyObject_CallObject(vefify_cb, arglist);

	 //printf("app_verify_callback 2\n");

	 
	 ret = PyLong_AsLong(result);
	 //printf("app_verify_callback ret:%d \n",ret);

 end:

	 Py_DECREF(result);
	 //Py_DECREF(arglist);
	 //ST

	 return ret;
 }

 int app_verify_all_pass_callback(X509_STORE_CTX *ctx, void *args)
 {
	 
	 //printf("app_verify_all_pass_callback : %s\n");

	 return 1;
 }



static PyObject *
_certificate_to_der(X509 *certificate)
{
	unsigned char *bytes_buf = NULL;
	int len;
	PyObject *retval;

	bytes_buf = NULL;
	len = i2d_X509(certificate, &bytes_buf);
	if (len < 0) {
		//_setSSLError(NULL, 0, __FILE__, __LINE__);
		return NULL;
	}
	/* this is actually an immutable bytes sequence */
	retval = PyBytes_FromStringAndSize((const char *)bytes_buf, len);
	OPENSSL_free(bytes_buf);
	return retval;
}

PyObject* py_build_date(PyObject *self, PyObject *args) {
	char	outbuff[2048] = { 0, };
	int	outbuff_size = 0;

	outbuff_size = sprintf(outbuff,"py_build_date %s %s\n", __DATE__, __TIME__);

	//printf("", outbuff);
	return PyUnicode_DecodeUTF8((const char*)outbuff, outbuff_size, "ENCODE ERROR");
	
	//return PyBytes_FromStringAndSize((const char*)outbuff, outbuff_size);
	//Py_RETURN_NONE;
}

PySSLSocket *_get_PySSLSocket_from_args(PyObject *args) {
	PySSLSocket *py_ssl_socket = NULL;
	if (PyArg_ParseTuple(args, "O", &py_ssl_socket)) {
		Py_INCREF(Py_None);
		
	}
	return py_ssl_socket;
}

static PyObject *py_get_peer_cert(PyObject *dummy, PyObject *args) {

	
	PyObject *result = Py_None;

	PySSLSocket *py_ssl_socket = NULL;
	X509 *peer_cert;
	py_ssl_socket =  _get_PySSLSocket_from_args(args);
	if (py_ssl_socket == NULL)
		return NULL; /* Pass error back */


	//printf("py_ssl_socket 0x%x \n", py_ssl_socket);
	//printf("py_ssl_socket->ssl 0x%x \n", py_ssl_socket->ssl);
	//printf("SSL size %d \n", sizeof(SSL));
	peer_cert = SSL_get_peer_certificate(py_ssl_socket->ssl);
	result = _certificate_to_der(peer_cert);
	/*bytes_buf = NULL;
	len = i2d_X509(peer_cert, &bytes_buf);
	print_hex("SSL_get_peer_certificate", len, bytes_buf);*/



	//printf("result :0x%x \n", result);


	
	return result;

	//return PyBytes_FromStringAndSize((const char*)outbuff, outbuff_size);

	Py_RETURN_NONE;
}


static PyObject *py_get_peer_cert_chains(PyObject *dummy, PyObject *args) {

	int arg = 0;
	PyObject *arglist;
	char	outbuff[2048] = { 0, };
	int	outbuff_size = 0;


	unsigned char* szSn = NULL;
	//unsigned char* aucPubKey = NULL;


	PyObject *result = NULL;
	PyObject *chain_cert = NULL;

	PySSLSocket *py_ssl_socket = NULL;
	X509 *peer_cert;
	unsigned char *bytes_buf = NULL;
	int len;
	if (!PyArg_ParseTuple(args, "O", &py_ssl_socket)) {
		PyErr_SetString(PyExc_TypeError, "parse args error");
		return NULL;
	}
	Py_INCREF(Py_None);
	result = Py_None;


	//printf("py_ssl_socket 0x%x \n", py_ssl_socket);
	//printf("py_ssl_socket->ssl 0x%x \n", py_ssl_socket->ssl);
	//printf("SSL size %d \n", sizeof(SSL));
	//printf("result :0x%x \n", result);

	stack_st_X509 * stack_x509 = SSL_get_peer_cert_chain(py_ssl_socket->ssl);
	int stack_num = sk_X509_num(stack_x509);
	//printf("stack_num : %d\n", stack_num);
	result = PyList_New(stack_num);
	
	for (int i = 0; i < stack_num;i++) {

		int len;
		unsigned char *buf = NULL;
		X509 *peer = sk_X509_value(stack_x509, i);
		chain_cert = _certificate_to_der(peer);
		PyList_SetItem(result,i, chain_cert);

	}



	return result;


	Py_RETURN_NONE;
}
static PyObject *py_set_all_pass(PyObject *dummy, PyObject *args) {
	PyObject *result = NULL;
	PyObject *vefify_cb = NULL;
	PySSLContext *py_ssl_context = NULL;
	SSL_CTX * ctx = NULL;
	int is_all_pass = 0;
	if (!PyArg_ParseTuple(args, "Op", &py_ssl_context,&is_all_pass)) {
		PyErr_SetString(PyExc_TypeError, "parse args error");
		
		return NULL; /* Pass error back */
	}
	if (!py_ssl_context) {
		PyErr_SetString(PyExc_TypeError, "py_ssl_context is NULL");
		return NULL; /* Pass error back */
	}
	printf("py_set_all_pass 0\n");
	if (!py_ssl_context->ctx) {
		PyErr_SetString(PyExc_TypeError, "py_ssl_context ssl is NULL");
		return NULL; /* Pass error back */
	}
	printf("py_set_all_pass py_ssl_context->ctx:%x\n", py_ssl_context->ctx);
	//
	//if (!PyCallable_Check(vefify_cb)) {
	//	PyErr_SetString(PyExc_TypeError, "cb_csr_sign parameter must be callable");
	//	return NULL;
	//}

	//result = Py_None;
	//Py_INCREF(Py_None);
	//

	//Py_XINCREF(vefify_cb);         /* Add a reference to new callback */
	//Py_XDECREF(g_cb_veify);  /* Dispose of previous callback */
	//g_cb_veify = vefify_cb;
	//py_ssl_socket->ssl;
	ctx = py_ssl_context->ctx;
	
	
	SSL_CTX_set_cert_verify_callback(ctx, is_all_pass ? app_verify_all_pass_callback:NULL, NULL);
	



	//return result;


	Py_RETURN_NONE;
}
static PyObject *py_check_verify_callback(PyObject *dummy, PyObject *args) {
	PyObject *result = NULL;
	PyObject *vefify_cb = NULL;
	SSL_CTX * ctx = NULL;
	//printf("py_check_verify_callback start\n");
	if (!PyArg_ParseTuple(args, "O",  &vefify_cb)) {

		PyErr_SetString(PyExc_TypeError, "parse args error");
		return NULL; /* Pass error back */
	}

	if (!PyCallable_Check(vefify_cb)) {
		PyErr_SetString(PyExc_TypeError, "cb_csr_sign parameter must be callable");
		return NULL;
	}
	//printf("py_check_verify_callback 0\n");
	result = Py_None;
	Py_INCREF(Py_None);

	
	Py_XINCREF(vefify_cb);         /* Add a reference to new callback */
	Py_XDECREF(g_cb_veify);  /* Dispose of previous callback */
	g_cb_veify = vefify_cb;
	//printf("py_check_verify_callback 1\n");
	
	int ret = app_verify_callback(NULL, vefify_cb);




	


	//printf("py_check_verify_callback ret : %d \n",ret);

	return PyLong_FromLong(ret);


	Py_RETURN_NONE;
}

static PyObject *py_set_fp(PyObject *dummy, PyObject *args) {
	Py_buffer inbuff;


	if (!PyArg_ParseTuple(args, "z*", &inbuff)) {
		return NULL;
	}
	int ret = 0;
	
	//fprintf(FPOUT, "py_set_fp");
	FILE * fp = NULL;
	if (!strcmp((char*)inbuff.buf, ""))
		set_fp(stdout);
	else
		
		fp = fopen((const char *)inbuff.buf, "wb");
		if (fp){
			set_fp(fp);

			
		}
		else{
			//printf("errno %d\n", errno);
		}
		

	//fprintf(FPOUT, "py_set_fp");
	//printf("inbuff.buf %s\n", inbuff.buf);
	//printf("py_set_fp 0x%x\n", FPOUT);
	

	PyBuffer_Release(&inbuff);
	
	



	Py_RETURN_NONE;
}
int convert_64sign_to_asn1_test(const unsigned char *sign64value, int sign64valueSize, unsigned char * asn1, int * asn1size);
int temp_test(const unsigned char *sign64value, int sign64valueSize);
static PyObject *py_test_malloc(PyObject *dummy, PyObject *args) {
	//Py_buffer inbuff;
	unsigned char	outbuff[2048] = { 0, };
	int	outbuff_size = 0;
	/*if (!PyArg_ParseTuple(args, "z*", &inbuff)) {
		return NULL;
	}
*/
	const unsigned char inbuff[] = { 0xBC, 0xC2, 0x29, 0x2B, 0x40, 0x2A, 0x5F, 0x8B, 0x40, 0x80, 0x88, 0xF3, 0xC3, 0xC0, 0xA1, 0xB5, 0xB4, 0x92, 0x44, 0x26, 0x6A, 0x5F, 0xEE, 0x21, 0x3B, 0x6D, 0x36, 0xFC, 0x4C, 0x20, 0xDB, 0x66, 0x3C, 0xD0, 0x9D, 0xAC, 0xBF, 0x4D, 0x1D, 0x1B, 0xDF, 0x16, 0xC5, 0xCD, 0xAE, 0xB5, 0x32, 0x39, 0xAE, 0x24, 0xFD, 0x59, 0xA3, 0x46, 0xDD, 0x93, 0x2B, 0x6D, 0x2F, 0x85, 0x3B, 0xDB, 0x50, 0x53, };


	//convert_64sign_to_asn1_test((unsigned char *)inbuff, sizeof(inbuff), outbuff, &outbuff_size);
	temp_test((unsigned char *)inbuff, sizeof(inbuff));

	//PyBuffer_Release(&inbuff);
	Py_RETURN_NONE;
	for(int i =0 ; i<10 ;i++){
		malloc(1024);
	}
	



	Py_RETURN_NONE;
}

static PyObject *py_open_ssl_free(PyObject *dummy, PyObject *args) {


	PyObject *free_object = NULL;

	if (!PyArg_ParseTuple(args, "O", &free_object)) {
		return NULL;
	}

	fprintf(FPOUT, "free_object 0x%x", free_object);
	
	OPENSSL_free(free_object);





	Py_RETURN_NONE;
}


static PyMethodDef ictk_ssl_ext_methods[] = {
    {
        "build_date", py_build_date, METH_NOARGS,
        "Print 'hello world' from a method defined in a C extension."
    },
	{
		"get_peer_cert", py_get_peer_cert, METH_VARARGS,
		"py_get_peer_cert"
	},
	{
		"get_peer_cert_chains", py_get_peer_cert_chains, METH_VARARGS,
		"py_get_peer_cert"
	},
	{
		"set_all_pass", py_set_all_pass, METH_VARARGS,
		"set_verify_callback"
	},
	{
		"check_verify_callback", py_check_verify_callback, METH_VARARGS,
		"check_verify_callback"
	},
	
	{
		"my_set_callback", my_set_callback, METH_VARARGS,
		"Print 'hello xxx' from a method defined in a C extension."
	},
	{
		"do_callback", do_callback, METH_VARARGS,
		"Print 'hello xxx' from a method defined in a C extension."
	},

    {NULL, NULL, 0, NULL}
};




// Module definition
// The arguments of this structure tell Python what to call your extension,
// what it's methods are and where to look for it's method definitions
static struct PyModuleDef ictk_ssl_definition = {
    PyModuleDef_HEAD_INIT,
    "ictk_ssl_ext",
    "ictk_ssl_ext is library for openssl handling ",
    -1,
	ictk_ssl_ext_methods
};

// Module initialization
// Python calls this function when importing your extension. It is important
// that this function is named PyInit_[[your_module_name]] exactly, and matches
// the name keyword argument in setup.py's setup() call.
PyMODINIT_FUNC PyInit__ictk_ssl_ext(void) {
    Py_Initialize();
    return PyModule_Create(&ictk_ssl_definition);
}
#endif
