#pragma once
#ifndef __NEO_UTIL_HEADER__
#define __NEO_UTIL_HEADER__
#include <openssl/bn.h>
#include <openssl/ec.h>


typedef struct _tagBUFFINFO {
	int size;
	unsigned char buff[4096];
}BUFFINFO;

#define FPOUT  get_fp()

FILE * get_fp();
void set_fp(FILE * fp);
int rand_serial(BIGNUM *b, ASN1_INTEGER *ai);
void print_hex(const  char* msg, int len, const unsigned char* buf);
BIO* get_bio_from_file(const char * filename);
int get_buffinfo_from_file(const char * filename, BUFFINFO *buffinfo);
int neo_bin_bub_to_ec_key(const unsigned char* aucPubKey, EC_KEY** eckey);;
unsigned short messageDigest(const unsigned char *pucData, unsigned short usDataLen, unsigned char* pucHash);
int Bn2Bin(const BIGNUM * pbignum, unsigned char *pbuff, int bytesize);

int ecdsa(const unsigned char *prk, int prk_size, const unsigned char *msg, int msg_size, unsigned char *sign, int *psign_size,  bool is_hashed);

int convert_64sign_to_asn1(const unsigned char *sign64value, int sign64valueSize, unsigned char * asn1, int * asn1size);
int convert_asn1_to_64sign(const unsigned char * asn1, int asn1size, unsigned char *sign64value, int * sign64valueSize);


int conv_longlong_to_asn1_integer(ASN1_INTEGER *ai, long long num);
#endif // !__NEO_UTIL_HEADER__
