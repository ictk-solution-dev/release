import datetime
import logging
import os
import re

import cryptography
import cryptography.hazmat
import requests
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from neolib.crypto_util_bin import sha256
from neolib.hexstr_util import tohexstr
from neolib.neo_class import NeoAltBytes

from auth_lib.exception import AuthLibVerifyCertException


class X509Handler:
	sx509: cryptography.x509.Certificate
	_shrink_name = {
		"organizationUnitName": "OU",
		"commonName": "CN",
		"organizationName": "O",
		"countryName": "C",
	}
	list_order = ["CN", "OU", "O", "C"]

	def __init__(self, cert_data=b'', encoding="DER",sx509=None):
		encoding = serialization.Encoding[encoding]
		if not sx509:
			if type(cert_data) == str:
				cert_data: str
				cert_data = cert_data.encode()
			crypto_be = cryptography.hazmat.backends.default_backend()
			if encoding == serialization.Encoding.DER:
				sx509 = x509.load_der_x509_certificate(cert_data, crypto_be)
			elif encoding == serialization.Encoding.PEM:
				sx509 = x509.load_pem_x509_certificate(cert_data, crypto_be)
			else:
				raise ValueError("NO ENCODING CERT")
		self.sx509 = sx509


	def _get_dotnames(self, sub):
		ret = ""
		dict_oid = {self._shrink_name.get(enxt.oid._name, enxt.oid._name): enxt.value for enxt in sub}
		list_key = list(dict_oid.keys())
		list_key.sort(key=lambda val: self.list_order.index(val) if val in self.list_order else 100)

		ret = ",".join([f"{key}={dict_oid[key]}" for key in list_key])
		return ret

	# def get_subject_key_id(self):
	# 	for enxt in self.sx509.extensions:
	# 		if enxt.oid.dotted_string == '2.5.29.14':
	# 			value = enxt.value
	# 			#print(value.oid.dotted_string, value.digest, tohexstr(value.digest))
	# 			return Bytes(value.digest)
	# 		#print(enxt.oid.dotted_string, str(enxt.oid), enxt.oid._name, enxt.value)
	#
	# 	pass
	#
	#
	#
	# def get_issue_date(self):
	# 	return self.sx509.not_valid_before
	#
	# def get_due_date(self):
	# 	return self.sx509.not_valid_after
	#
	# def get_subject_common_name(self):
	#
	# 	for enxt in self.sx509.subject:
	# 		if enxt.oid.dotted_string == '2.5.4.3':
	# 			return enxt.value
	#
	#
	# def get_subject(self):
	# 	ret =""
	# 	return self._get_dotnames(self.sx509.subject)
	#
	#
	# def get_issuer(self):
	# 	return self._get_dotnames(self.sx509.issuer)
	#
	#
	# def get_issuer_common_name(self):
	# 	#print(tohexstr(bn_der))
	# 	for enxt in self.sx509.issuer:
	# 		print(enxt.oid._name)
	# 		if enxt.oid.dotted_string == '2.5.4.3':
	# 			return enxt.value
	#
	#
	# def get_public_key(self):
	# 	return self.sx509.public_key()

	@property
	def subject_key_id(self):
		for enxt in self.sx509.extensions:
			if enxt.oid.dotted_string == '2.5.29.14':
				value = enxt.value
				# print(value.oid.dotted_string, value.digest, tohexstr(value.digest))
				return NeoAltBytes(value.digest)
		# print(enxt.oid.dotted_string, str(enxt.oid), enxt.oid._name, enxt.value)

		pass

	@property
	def issue_date(self):
		return self.sx509.not_valid_before

	@property
	def due_date(self):
		return self.sx509.not_valid_after

	@property
	def subject_common_name(self):

		for enxt in self.sx509.subject:
			if enxt.oid.dotted_string == '2.5.4.3':
				return enxt.value

	@property
	def subject(self):
		ret = ""
		return self._get_dotnames(self.sx509.subject)

	@property
	def issuer(self):
		return self._get_dotnames(self.sx509.issuer)

	@property
	def issuer_common_name(self):
		# print(tohexstr(bn_der))
		for enxt in self.sx509.issuer:
			#print(enxt.oid._name)
			if enxt.oid.dotted_string == '2.5.4.3':
				return enxt.value

	@property
	def public_key(self):
		return self.sx509.public_key()

	def get_subject_key_id(self):
		return self.subject_key_id

	def get_issue_date(self):
		return self.issue_date

	def get_due_date(self):
		return self.due_date

	def get_subject_common_name(self):
		return self.subject_common_name

	def get_subject(self):
		return self.subject

	def get_issuer(self):
		return self.issuer

	def get_issuer_common_name(self):
		return self.issuer_common_name

	def get_public_key(self):
		return self.public_key

	def verify_cert(self, cert: x509.Certificate):
		#print(self.sx509.signature_algorithm_oid)
		# if self.sx509.signature_algorithm_oid.dotted_string != "1.2.840.10045.4.3.2":
		# 	raise AuthLibVerifyCertException("CERT must be ECDSA with sha256")
#		pubkey = self.sx509.public_key()
		print(cert.signature)
		self.verify_signature(cert.tbs_certificate_bytes,cert.signature)
		# crypto_be = cryptography.hazmat.backends.default_backend()
		#
		# verifier = pubkey.verify(
		# 	cert.signature,
		# 	cert.tbs_certificate_bytes,
		# 	#crypto_be
		# 	ec.ECDSA(hashes.SHA256())
		# )

	def verify_signature(self, msg,signature):
		#print(self.sx509.signature_algorithm_oid)
		if self.sx509.signature_algorithm_oid.dotted_string != "1.2.840.10045.4.3.2":
			raise AuthLibVerifyCertException("CERT must be ECDSA with sha256")
		pubkey = self.sx509.public_key()
		crypto_be = cryptography.hazmat.backends.default_backend()
		verifier = pubkey.verify(
			signature,
			msg,
			#crypto_be
			ec.ECDSA(hashes.SHA256())
		)

	def to_pem(self):
		bn_pem = self.sx509.public_bytes(serialization.Encoding.PEM)
		bn_pem: bytes

		return bn_pem.decode()

	def to_der(self):
		return NeoAltBytes(self.sx509.public_bytes(serialization.Encoding.DER))

	def to_hash(self):

		return NeoAltBytes(sha256(self.sx509.public_bytes(serialization.Encoding.DER)))

	def __str__(self):
		return f"SUB:{self.get_subject_common_name()} ISSUE:{self.get_issuer_common_name()} SUB KEY {tohexstr(self.get_subject_key_id())}"

	def to_contents(self):
		dict_ret = dict(
			subject=self.get_subject(),
			issuer=self.get_issuer(),
			subject_key_id=self.get_subject_key_id().hexstr.lower(),
			der_hash=self.to_hash(),
			pem=self.to_pem(),

		)
		return dict_ret